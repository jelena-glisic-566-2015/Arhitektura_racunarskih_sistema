/*
 * Project name:
     DEMO 
 * Copyright:
     (c) Mikroelektronika, 2011.
 * Description:
     This is a simple project. It turns on/off diodes connected to all ports.
 * Test configuration:
     MCU:             LPC2214
     Dev.Board:       UNIDS6
                      http://www.mikroe.com/eng/products/view/669/uni-ds6-development-system/
     Oscillator:      14.74568MHz (cclk = 58.98272MHz, Fcco = 235.93088 MHz)
     Ext. Modules:    -
     SW:              KEIL uVision v4.10
 * NOTES:
     - Turn ON LEDs on PORT0, PORT1 and PORT2 (Switch SW12).
*/



#include <LPC22XX.H>

#include "Utility.h"


int main (void)
{
	PINSEL0 = 0;
	PINSEL1 = 0;
	PINSEL2 &= 0x0000000C;
	PINSEL2 |= 0x00000030;
	DelayProc(0.2 * CCLOCK);


	IODIR0 = 0x00000001;					// P0.0 - P0.31 defined as Outputs
	IODIR1 = 0x00000001;					// P1.0 - P1.31 defined as Outputs
	IODIR2 = 0x00000001;					// P2.0 - P2.31 defined as Outputs

	while (1)
		{
		IOSET0 = 0x00000001;
		IOSET1 = 0x00000001;
		IOSET2 = 0x00000001;
		DelayProc(0.250 * CCLOCK);

		IOCLR0 = 0x00000001;
		IOCLR1 = 0x00000001;
		IOCLR2 = 0x00000001;
		DelayProc(0.250 * CCLOCK);
		}
}